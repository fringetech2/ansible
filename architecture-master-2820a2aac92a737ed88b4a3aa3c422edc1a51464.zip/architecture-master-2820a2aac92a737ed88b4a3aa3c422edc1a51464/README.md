This is a sample README for the Managing Files in Git exercise in DO417

### Description: Manages the W32Time service
commit

...
